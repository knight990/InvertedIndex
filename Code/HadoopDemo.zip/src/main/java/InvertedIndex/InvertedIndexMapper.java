package InvertedIndex;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;

public class InvertedIndexMapper extends Mapper<LongWritable, Text,
        Text, Text> {

    private static Text keyInfo = new Text();
    private static Text keyInfo1 = new Text();


    /**
     *
     * @param key
     * @param value
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {

        String line = value.toString();
        String[] fields = line.split(" ");

        FileSplit fileSplit = (FileSplit) context.getInputSplit();
        String fileName = fileSplit.getPath().getName();

        for (String field : fields) {
            keyInfo.set(field + ":" + fileName);
            keyInfo1.set("1");
            context.write(keyInfo, keyInfo1);
        }

    }
}
