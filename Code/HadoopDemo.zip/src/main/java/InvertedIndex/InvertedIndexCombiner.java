package InvertedIndex;

import org.apache.hadoop.mapreduce.Reducer;
import org.w3c.dom.*;

import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
//import javax.xml.soap.Text;
import org.apache.hadoop.io.Text;

import java.io.IOException;

public class InvertedIndexCombiner extends Reducer<Text, Text, Text, Text> {


    private static Text v2 = new Text();
    private static Text k2 = new Text();


    /**
     *
     * @param key
     * @param values
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    @Override
    protected void reduce(Text key, Iterable<Text> values,
                          Context context) throws IOException, InterruptedException {

        int sum = 0;
        for (Text value : values) {
            sum += Integer.parseInt(value.toString());
        }

        int spiltIndex = key.toString().indexOf(":");


        String value2 = key.toString().substring(spiltIndex + 1) + ":" + sum;
        v2.set(value2);
        String key2 = key.toString().substring(0, spiltIndex);
        k2.set(key2);
        context.write(k2, v2);

    }

}
